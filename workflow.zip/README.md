# docker-hub.alfredworkflow

An Alfred PowerPack Workflow for searching Docker Hub for public Docker images.

## Installation

Download `docker-hub.alfredworkflow` from the [latest release](https://github.com/cdzombak/docker-hub.alfredworkflow/releases/latest) and double-click `docker-hub.alfredworkflow` to install it.

## Usage

`dockerhub {query}` — Search for an image.

### Actions

- `↩` — Open the module in the Docker Hub UI
- `⇧/⌘Y` — QuickLook details

## Screenshots

![beginning a search](readme.images/README.png)  
![search results](readme.images/README2.png)  
![no results found](readme.images/README3.png)  
![quicklook details](readme.images/README4.png)

## About

TODO

## License

TODO
