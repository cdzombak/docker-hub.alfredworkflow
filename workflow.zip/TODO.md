# TODO

- [ ] Test build product
- [ ] Can I ship the .alfredworkflow in a .pkg or some other signed structure, or otherwise sign the `hub` binary?
- [ ] Complete README
- [ ] GitHub CI for release
